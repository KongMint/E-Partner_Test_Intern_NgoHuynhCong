import "./index.css";
import data from "./customer";
import "./table.css";
import { useState } from "react";
import { useEffect } from "react";

function App() {
  const [originData, setOriginData] = useState([]);
  const [customer, setCustomer] = useState([]);
  const [search, setSearch] = useState("");

  const searchByIdOrName = (value) => {
    const result = originData.filter(
      (item) =>
        item.customerID.toLowerCase().includes(value.toLowerCase()) ||
        item.contactName.toLowerCase().includes(value.toLowerCase())
    );
    setCustomer(result);
  };

  const handleChange = (e) => {
    setSearch(e.target.value);
    searchByIdOrName(e.target.value);
  };

  const handleSort = (e) => {
    const option = e.target.value;
    let currentValue = [...customer];
    if (option == 0) {
    } else if (option == 1) {
      currentValue.sort(function (a, b) {
        return a.customerID - b.customerID ? -1 : 1;
      });
    } else if (option == 2) {
      currentValue.sort(function (a, b) {
        return a.customerID - b.customerID ? 1 : -1;
      });
    } else if (option == 3) {
      currentValue.sort(function (a, b) {
        return a.contactName.split(" ")[0] - b.contactName.split(" ")[0]
          ? -1
          : 1;
      });
    } else {
      currentValue.sort(function (a, b) {
        return a.contactName.split(" ")[0] - b.contactName.split(" ")[0]
          ? 1
          : -1;
      });
    }
    setCustomer(currentValue);
  };

  useEffect(() => {
    setCustomer(data);
    setOriginData(data);
  }, []);

  return (
    <div className="App">
      <div className="container">
        <form className="Searchform">
          <input
            onChange={handleChange}
            value={search}
            type="text"
            placeholder="Search by CustomerId or ContactName"
          />
        </form>

        <select name="selection" id="options" onChange={handleSort}>
          <option value="0">Sort option</option>
          <option value="1">Ascending by ID</option>
          <option value="2">Descending by ID</option>
          <option value="3">Ascending by CustomerName</option>
          <option value="4">Descending by CustomerName</option>
        </select>
      </div>

      <table>
        <span>Number of records: {customer.length}</span>
        <tr>
          <th className="th">CustomerID</th>
          <th className="th">CustomerName</th>
          <th className="th">ContactName</th>
          <th className="th">CompanyTitle</th>
          <th className="th">Address</th>
          <th className="th">City</th>
          <th className="th">Region</th>
          <th className="th">PostalCode</th>
          <th className="th">Country</th>
          <th className="th">Phone</th>
          <th className="th">Fax</th>
        </tr>
        {customer.length > 0 ? (
          customer.map((val, key) => {
            return (
              <tr key={key}>
                <td>{val.customerID}</td>
                <td>{val.customerName}</td>
                <td>{val.contactName}</td>
                <td>{val.contactTilte}</td>
                <td>{val.address}</td>
                <td>{val.city}</td>
                <td>{val.Region}</td>
                <td>{val.postalCode}</td>
                <td>{val.country}</td>
                <td>{val.phone}</td>
                <td>{val.fax}</td>
              </tr>
            );
          })
        ) : (
          <div>No result found</div>
        )}
      </table>
    </div>
  );
}

export default App;
