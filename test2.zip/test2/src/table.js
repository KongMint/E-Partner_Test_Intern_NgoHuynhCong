obj = {
    customerID: 'ALFKI',
    customerName: 'Alfreds Futterkiste',
    contactName: 'Maria Anders',
    contactTilte: 'Sales Representative',
    address: 'Obere Str. 57',
    city: 'Berlin',
    Region: NULL,
    postalCode:'12209',
    country:'Germany',
    phone: '030-0074321',
    fax: '030-0076545'
}
  
  obj = {
    customerID:'ANATR',
    customerName:'Ana Trujillo Emparedados y helados',
    contactName:'Ana Trujillo',
    contactTilte:'Owner',
    address:'Avda. de la Constitución 2222',
    city:'México D.F.',
    Region: NULL,
    postalCode:'05021',
    country:'Mexico',
    phone:'(5) 555-4729',
    fax:'(5) 555-3745'
}

obj ={
    customerID:'ANTON',
    customerName:'Antonio Moreno Taquería',
    contactName:'Antonio Moreno',
    contactTilte:'Owner',
    address:'Mataderos  2312',
    city:'México D.F.',
    Region: NULL,
    postalCode:'05023',
    country:'Mexico',
    phone:'(5) 555-3932',
    fax: NULL
}

obj = {
    customerID:'AROUT',
    customerName:'Around the Horn',
    contactName:'Thomas Hardy',
    contactTilte:'Sales Representative',
    address:'120 Hanover Sq.',
    city:'London',
    Region:NULL,
    postalCode:'WA1 1DP',
    country:'UK',
    phone:'(171) 555-7788',
    fax:'(171) 555-6750'
}